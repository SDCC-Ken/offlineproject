--Operational level query 1
SELECT e.lessonCode,m.fullMajorName,COUNT(s.majorCode) AS numOfStudent
FROM student s, enrollment e, lesson l,major m
WHERE m.majorCode = s.majorCode
AND s.id = e.studentID
AND e.lessonCode = l.lessonCode
AND l.years = year(getdate())
AND e.lessonCode = (SELECT DISTINCT l.lessonCode
					FROM lecture l,lecturer r
					WHERE l.lecturerID = r.id
					AND r.id = 42)
GROUP BY m.fullMajorName,e.lessonCode;
--Operational level query 2
SELECT majorcode,MIN(cGPA) AS MINcGPA,MAX(cGPA) AS MAXcGPA,AVG(cGPA) AS AVGcGPA
FROM student
GROUP BY majorCode;
--Managerial level query 1
SELECT lDate,startTime,endTime,venue
FROM lecture
WHERE lDate = (SELECT CONVERT(date, getdate()))
UNION
SELECT tDate,startTime,endTime,venue
FROM tutorial
WHERE tDate = (SELECT CONVERT(date, getdate()));
--Managerial level query 2
SELECT lastName,firstName,majorCode,cGPA
FROM student
WHERE cGPA>3.7;